package com.team36.constant;

public enum MemberRole {

    USER,  ADMIN;

}