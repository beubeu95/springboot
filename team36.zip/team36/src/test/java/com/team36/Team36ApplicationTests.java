package com.team36;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Team36ApplicationTests {

	@Test
	void contextLoads() {
	}

}
